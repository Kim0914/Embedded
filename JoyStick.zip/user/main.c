#define  RCC_APB2ENR    (*(volatile unsigned int*)0x40021018) 
#define  GPIOA_CRL     (*(volatile unsigned int*)0x40010800)
#define  GPIOB_CRL     (*(volatile unsigned int*)0x40010C00)
#define  GPIOB_ODR    (*(volatile unsigned int*)(0x40010C00 + 0x0C))
#define  GPIOC_CRL     (*(volatile unsigned int*)0x40011000)
#define  GPIOC_ODR    (*(volatile unsigned int*)(0x40011000 + 0x0C))
#define  GPIOD_CRL     (*(volatile unsigned int*)0x40011400)
#define  GPIOD_BSRR    (*(volatile unsigned int*)(0x40011400 + 0x10))

int main()
{

  unsigned int stick_status = 0;
  RCC_APB2ENR |= (1<<3) | (1<<5);    
  GPIOD_CRL &= (0x0FF000FF);
  GPIOD_CRL |= (0x30033300);
  
  GPIOC_CRL &= (0xFF0000FF);
  GPIOC_CRL |= (0x00444400);
  
  while(1){
    stick_status = GPIOC_ODR;
    if(GPIOC_ODR & (1 << 2)){
      GPIOD_BSRR = (1 << 4) | (1 << 7);
    }
    else if(GPIOC_ODR & (1 << 3)){
      GPIOD_BSRR = (0 << 4) | (0 << 7);
    }
    
    else if(GPIOC_ODR & (1 << 4)){
      GPIOD_BSRR = (1 << 2) | (1 << 3);
    }
    
    else if(GPIOC_ODR & (1 << 5)){
      GPIOD_BSRR = (0 << 2) | (0 << 3);
    }
    
  }
  
  GPIOD_BSRR = 0xffffffff;

  while(1);
}
